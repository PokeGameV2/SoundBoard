CREATE DATABASE IF NOT EXISTS `CLASSES` DEFAULT CHARACTER SET UTF8MB4 COLLATE utf8_general_ci;
USE `CLASSES`;

CREATE TABLE `CLASSE` (
  `id_classe` VARCHAR(42),
  `nombre_eleves` VARCHAR(42),
  `nomination` VARCHAR(42),
  `ens_pro` VARCHAR(42),
  `id_matiere` VARCHAR(42),
  PRIMARY KEY (`id_classe`)
) ENGINE=InnoDB DEFAULT CHARSET=UTF8MB4;

CREATE TABLE `DISCIPLINE` (
  `code_discipline` VARCHAR(42),
  `capacité` VARCHAR(42),
  `effectif` VARCHAR(42),
  `nbdegroupe` VARCHAR(42),
  `nombre_heures` VARCHAR(42),
  `discipline` VARCHAR(42),
  `code_discipline_1` VARCHAR(42),
  PRIMARY KEY (`code_discipline`)
) ENGINE=InnoDB DEFAULT CHARSET=UTF8MB4;

CREATE TABLE `ENSEIGNANT` (
  `discipline` VARCHAR(42),
  `nom` VARCHAR(42),
  `prenom` VARCHAR(42),
  `statut` VARCHAR(42),
  `amenagement` VARCHAR(42),
  `decharge` VARCHAR(42),
  `nombre_heures_obligatoires` VARCHAR(42),
  `apport` VARCHAR(42),
  `ecart` VARCHAR(42),
  `heure_poste` VARCHAR(42),
  `heures_supplémentaires_années_(hsa)` VARCHAR(42),
  `ara` VARCHAR(42),
  `supports_définitifs` VARCHAR(42),
  PRIMARY KEY (`discipline`)
) ENGINE=InnoDB DEFAULT CHARSET=UTF8MB4;

CREATE TABLE `GROUPE` (
  `id_groupe` VARCHAR(42),
  `nomination` VARCHAR(42),
  `id_classe` VARCHAR(42),
  PRIMARY KEY (`id_groupe`)
) ENGINE=InnoDB DEFAULT CHARSET=UTF8MB4;

CREATE TABLE `MATIERE` (
  `id_matiere` VARCHAR(42),
  `code_discipline` VARCHAR(42),
  `id_matiere_formation` VARCHAR(42),
  PRIMARY KEY (`id_matiere`)
) ENGINE=InnoDB DEFAULT CHARSET=UTF8MB4;

ALTER TABLE `CLASSE` ADD FOREIGN KEY (`id_matiere`) REFERENCES `MATIERE` (`id_matiere`);
ALTER TABLE `DISCIPLINE` ADD FOREIGN KEY (`discipline`) REFERENCES `ENSEIGNANT` (`discipline`);
ALTER TABLE `GROUPE` ADD FOREIGN KEY (`id_classe`) REFERENCES `CLASSE` (`id_classe`);
ALTER TABLE `MATIERE` ADD FOREIGN KEY (`code_discipline`) REFERENCES `DISCIPLINE` (`code_discipline`);